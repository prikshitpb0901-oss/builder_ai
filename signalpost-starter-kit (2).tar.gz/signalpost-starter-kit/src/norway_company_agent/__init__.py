"""Norway company enrichment POC."""

